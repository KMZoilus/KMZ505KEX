All-in-one game dumper for PS4 v1.8 with gengp4 v1.8

Brief instructions:
-------------------

1) Turn on the console, insert disc (or run psn title), install all game patches;
2) Plug-in the USB stick, run the ps4-dumper payload (.bin or standalone);
3) Run your game, make sure to get main menu, minimize game (PS Button);
4) Wait till completion. When the process is finished the console will shutdown
   automatically (it is normal, not a panic shutdown);
5) Turn on your console, remove disc, uninstall the game (for further testing);
6) On PC: Plug-in the USB Stick, then open gengp4.exe, point into CUSAxxxxx-* dir
   and press Generate .GP4, You should get the 'Done.', then press Save .GP4;
7) Open .gp4 in the orbis-pub-gen and build .pkg file
   (You can get the orbis-pub-gen tool via PKG_Fake_Generator);
8) Run PS4HEN payload, install and test your .pkg;
9) Enjoy.
